package creations.rimov.com.chipit.constants

object ChipTouchAction {
    const val DRAW_PATH = 300
    const val SWIPE_UP = 400
}