package creations.rimov.com.chipit.util

interface AsyncHandler {

    fun <T> setData(data: T)
}