package creations.rimov.com.chipit.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import creations.rimov.com.chipit.extensions.getChipFileDate
import creations.rimov.com.chipit.extensions.getChipUpdateDate
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

object CameraUtil {

    class ImageFile(val file: File, val storagePath: String)

    const val CODE_TAKE_PICTURE = 100
    const val CODE_GET_IMAGE = 200
    const val IMAGE_PROVIDER_AUTHORITY = "com.rimov.creations.chipit.fileprovider"

    private const val IMG_FILENAME_PREFIX = "ChipIt_IMG_"

    @JvmStatic
    fun getImageFile(storageDir: File? = null): ImageFile? {

        //TODO FUTURE: handle this
        if(!isExternalStorageAvailable()) return null

        return try {
            val directory = storageDir ?:
                            if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
                                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                            else null

            createImageFile(directory)

        } catch(e: IOException) {
            e.printStackTrace()
            null
        }
    }

    @JvmStatic
    fun getImageUri(context: Context, imageFile: File): Uri =
        FileProvider.getUriForFile(context, IMAGE_PROVIDER_AUTHORITY, imageFile)

    //TODO: consider adding a verification method to ensure no unnecessary files are somehow deleted
    @JvmStatic
    fun deleteImageFile(imagePath: String) = File(imagePath).delete()

    @JvmStatic
    private fun createImageFile(storageDir: File?): ImageFile? {

        if(storageDir == null) return null

        //TODO: consider modifying locale based on phone location
        val time = Date().getChipFileDate()
        val file = File(
            storageDir,
            "$IMG_FILENAME_PREFIX$time.jpg")

        Log.i("ImageFile", "File path: ${file.absoluteFile}")

        return ImageFile(file, file.absolutePath)
    }

    @JvmStatic
    private fun isExternalStorageAvailable(): Boolean = Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED
}